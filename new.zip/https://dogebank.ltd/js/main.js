$(function() {

	new WOW().init();

	$('.navbar-tog').click(function() {
		$(this).toggleClass('navbar-on');
		$('.header__block').toggleClass('active');
	});

	$('.header__language_title').click(function() {
		$(this).toggleClass('active');
		$(this).next().slideToggle(300);
	});

	$('.modal__close').click(function() {
		$(this).parent().parent().parent().fadeOut(300);
	});
	$('.modal__blackout').click(function() {
		$(this).parent().parent().fadeOut(300);
	});


	$("input.pay").click(function(){
	
     var lid = $(this).data('pay');
	 var _this = this;
	
     if(lid){
     $(_this).prop("disabled", true);
     $(_this).val("Loading..."); 


	 $.ajax({
			url: "/coin/ajaxpay.php",
			dataType: "json",
			type: "post",
			data: {
				"payid": lid,
			},
			beforeSend: function (res) {
			
				
			},
			success: function (res) {
	

     $(_this).val("Pay"); 
     $(_this).prop("disabled", false); 
     alert(res.text);
	 if(res.status == "success"){
	 location = "";
	 }
			}
     });
     }
     return false;
     });

});